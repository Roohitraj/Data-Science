/*
  # Create movies table

  1. New Tables
    - `movies`
      - `id` (bigint, primary key)
      - `title` (text, not null)
      - `poster_path` (text)
      - `backdrop_path` (text)
      - `overview` (text)
      - `release_date` (date)
      - `created_at` (timestamp with time zone)

  2. Security
    - Enable RLS on `movies` table
    - Add policy for authenticated users to read movies
*/

CREATE TABLE IF NOT EXISTS movies (
  id bigint PRIMARY KEY,
  title text NOT NULL,
  poster_path text,
  backdrop_path text,
  overview text,
  release_date date,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE movies ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow authenticated users to read movies"
  ON movies
  FOR SELECT
  TO authenticated
  USING (true);