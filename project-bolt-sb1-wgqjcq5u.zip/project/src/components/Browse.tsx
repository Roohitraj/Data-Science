import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '@/lib/store';
import { Button } from './ui/button';
import { supabase } from '@/lib/supabase';

export function Browse() {
  const navigate = useNavigate();
  const user = useStore((state) => state.user);
  const movies = useStore((state) => state.movies);
  const setMovies = useStore((state) => state.setMovies);
  const setUser = useStore((state) => state.setUser);
  const setAuthenticated = useStore((state) => state.setAuthenticated);

  useEffect(() => {
    if (!user) {
      navigate('/login');
    } else {
      fetchMovies();
    }
  }, [user, navigate]);

  const fetchMovies = async () => {
    try {
      const { data, error } = await supabase
        .from('movies')
        .select('*');

      if (error) throw error;
      setMovies(data || []);
    } catch (error) {
      console.error('Error fetching movies:', error);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setAuthenticated(false);
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-zinc-900">
      <nav className="bg-black bg-opacity-90 fixed w-full z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/0/08/Netflix_2015_logo.svg"
            alt="Netflix"
            className="h-8"
          />
          <Button onClick={handleLogout} variant="ghost" className="text-white">
            Sign Out
          </Button>
        </div>
      </nav>

      <div className="pt-24 px-4">
        <h2 className="text-2xl font-bold text-white mb-6">Popular on Netflix</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {movies.map((movie) => (
            <div key={movie.id} className="relative group">
              <img
                src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
                alt={movie.title}
                className="rounded-md transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-60 transition-opacity duration-300 rounded-md flex items-center justify-center">
                <div className="opacity-0 group-hover:opacity-100 text-white text-center p-4">
                  <h3 className="font-bold">{movie.title}</h3>
                  <p className="text-sm mt-2">{movie.release_date}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}