import { create } from 'zustand';

interface Movie {
  id: number;
  title: string;
  poster_path: string;
  backdrop_path: string;
  overview: string;
  release_date: string;
}

interface AuthState {
  isAuthenticated: boolean;
  user: any | null;
  movies: Movie[];
  setUser: (user: any) => void;
  setAuthenticated: (status: boolean) => void;
  setMovies: (movies: Movie[]) => void;
}

export const useStore = create<AuthState>((set) => ({
  isAuthenticated: false,
  user: null,
  movies: [],
  setUser: (user) => set({ user }),
  setAuthenticated: (status) => set({ isAuthenticated: status }),
  setMovies: (movies) => set({ movies }),
}));